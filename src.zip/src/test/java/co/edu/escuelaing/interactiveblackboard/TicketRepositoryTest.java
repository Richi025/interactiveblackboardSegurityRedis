package co.edu.escuelaing.interactiveblackboard;



public class TicketRepositoryTest {

}

